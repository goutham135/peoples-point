

  <!-- end navbar-default -->
  <div class="table">
    <div class="table-cell">
      <div class="container">
        <h3>TESTIMONIALS</h3>
      </div>
      <!-- end container --> 
    </div>
    <!-- end table-cell --> 
  </div>
  <!-- end table --> 
</header>
<!-- end header -->


<section class="testimonials">
  <div class="container">
    <div class="row">
     <div class="col-xs-12 text-center">
     	<h6>HAPPY CLIENTS</h6>
     	<h2>Testimonials from our proudly clients</h2>
     </div>
     <!-- end col-12 -->
      <div class="col-xs-12">
       <div class="owl-slider">
       <div><div class="testimonial-box">
          <figure class="head"> <img src="<?php echo base_url('assets/')?>images/headshot1.jpg" alt="Image"> </figure>
          <h5>Velcom Communication</h5>
          <small>Jessica Carter (Company CEO)</small> <span class="rates"> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> </span>
          <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipis civelit sed quia non qui dolorem ipsum quia dolor sit amet, consectetur, adipis civelit sed quia numquam eius modi. Neque porro quisquam est.</p>
        </div>
        <!-- end testimonial-box --> </div>
        <!-- end div -->
       <div><div class="testimonial-box">
          <figure class="head"> <img src="<?php echo base_url('assets/')?>images/headshot2.jpg" alt="Image"> </figure>
          <h5>KyevStar Mobile</h5>
          <small>Maria Slovenia (Marketting Manager)</small> <span class="rates"> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> </span>
          <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipis civelit sed quia non qui dolorem ipsum quia dolor sit amet, consectetur, adipis civelit sed quia numquam eius modi. Neque porro quisquam est.</p>
        </div>
        <!-- end testimonial-box --> </div>
        <!-- end div -->
        <div><div class="testimonial-box">
          <figure class="head"> <img src="<?php echo base_url('assets/')?>images/headshot3.jpg" alt="Image"> </figure>
          <h5>Zegna Clothes</h5>
          <small>Nathalia McPorter (Business Developer)</small> <span class="rates"> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> </span>
          <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipis civelit sed quia non qui dolorem ipsum quia dolor sit amet, consectetur, adipis civelit sed quia numquam eius modi. Neque porro quisquam est.</p>
        </div>
        <!-- end testimonial-box --> </div>
        <!-- end div -->
       </div>
        <!-- end owl-slider -->
      </div>
      <!-- end col-12 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</section>

